var RecipeCategories = (function () {
    function RecipeCategories() {
        this.items = [];
    }
    return RecipeCategories;
})();
//# sourceMappingURL=recipeCategories.js.map