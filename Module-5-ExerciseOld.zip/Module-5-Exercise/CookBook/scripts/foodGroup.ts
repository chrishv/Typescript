﻿class FoodGroup {
    private _name: string;

    //get and set block for the member variable above. 
    get name() {
        return this._name;
    }

    set name(name : string) {
        this._name = name;
    }

} 