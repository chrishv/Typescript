﻿class RecipeCategories {
    items: BaseRecipeCategory[] = [];
}